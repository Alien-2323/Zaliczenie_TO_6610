<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Wybór typu konta bankowego</description>
   <name>dropdown_type</name>
   <tag></tag>
   <elementGuidId>a3eb662a-51f7-4686-9db2-11704cdbbf96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[id=&quot;type&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
