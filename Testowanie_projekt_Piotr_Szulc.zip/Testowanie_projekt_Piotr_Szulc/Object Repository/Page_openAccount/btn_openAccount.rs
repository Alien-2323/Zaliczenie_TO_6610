<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Opcja otwarcia nowego konta</description>
   <name>btn_openAccount</name>
   <tag></tag>
   <elementGuidId>8d934e45-7999-4d8b-8246-ff36e2f4ebf1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[value=&quot;Open New Account&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
