<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Opcja zaloguj</description>
   <name>btn_login</name>
   <tag></tag>
   <elementGuidId>b539c6eb-bbd1-4fbf-a514-900ed8d79baf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[value = &quot;Log In&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
