<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Identyfikator użytkownika</description>
   <name>inp_login_username</name>
   <tag></tag>
   <elementGuidId>2754e391-a6af-4ee3-a5f0-cb16cb655fad</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[name=&quot;username&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
