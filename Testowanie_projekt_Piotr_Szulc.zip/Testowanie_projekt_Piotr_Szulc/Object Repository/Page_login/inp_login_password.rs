<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Hasło użytkownika</description>
   <name>inp_login_password</name>
   <tag></tag>
   <elementGuidId>b68bf5a1-b20a-4fee-8454-7706436328a8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[name=&quot;password&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
