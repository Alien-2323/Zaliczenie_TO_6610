<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Nazwa użytkownika wyświetlana przez stronę po weryfikacji danych</description>
   <name>str_customer_name</name>
   <tag></tag>
   <elementGuidId>d5f38823-d799-4cff-beef-2b806a7bf5ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#leftPanel > p</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
