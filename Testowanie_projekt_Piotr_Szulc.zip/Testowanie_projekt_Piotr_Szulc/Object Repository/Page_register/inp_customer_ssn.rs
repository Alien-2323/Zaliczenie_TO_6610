<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Numer SSN (PESEL) użytkownika</description>
   <name>inp_customer_ssn</name>
   <tag></tag>
   <elementGuidId>c33c4844-6f1e-4a9a-9124-744252de8618</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer.ssn&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
