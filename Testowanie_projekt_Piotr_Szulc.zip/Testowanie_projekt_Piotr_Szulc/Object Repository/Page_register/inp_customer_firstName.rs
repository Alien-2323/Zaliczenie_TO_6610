<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Imię użytkownika</description>
   <name>inp_customer_firstName</name>
   <tag></tag>
   <elementGuidId>3cdbba3e-bc37-4ad7-ae72-71e3df38c229</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer.firstName&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
