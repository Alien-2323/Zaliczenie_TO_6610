<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Numer telefonu użytkownika</description>
   <name>inp_customer_phoneNumber</name>
   <tag></tag>
   <elementGuidId>c9b82610-90f5-4313-a775-700c7115f261</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer.phoneNumber&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
