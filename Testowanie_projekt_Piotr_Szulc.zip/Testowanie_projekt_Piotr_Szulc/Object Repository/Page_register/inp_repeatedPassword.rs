<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Potwierdzenie hasła</description>
   <name>inp_repeatedPassword</name>
   <tag></tag>
   <elementGuidId>9e635e33-3403-4155-800f-4015e02d92c9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;repeatedPassword&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
