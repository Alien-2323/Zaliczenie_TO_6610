<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Nazwisko użytkownika</description>
   <name>inp_customer_lastName</name>
   <tag></tag>
   <elementGuidId>b7fe85a5-e255-4cbd-8f6c-ef6b218100ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer.lastName&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
