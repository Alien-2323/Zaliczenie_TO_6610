<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Adres użytkownika - stan</description>
   <name>inp_customer_state</name>
   <tag></tag>
   <elementGuidId>599717f2-a520-4ee6-badc-ff67f6aeab05</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer.address.state&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
