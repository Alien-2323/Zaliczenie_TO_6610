<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Adres zamieszkania - miasto</description>
   <name>inp_customer_city</name>
   <tag></tag>
   <elementGuidId>034eaf72-b3f9-46d9-951d-bbacb5541aa6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer.address.city&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
