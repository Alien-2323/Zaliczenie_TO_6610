<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Adres zamieszkania - ulica</description>
   <name>inp_customer_street</name>
   <tag></tag>
   <elementGuidId>0a0545ef-e4cf-4d1a-a4fd-4cca0947f05d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer.address.street&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
