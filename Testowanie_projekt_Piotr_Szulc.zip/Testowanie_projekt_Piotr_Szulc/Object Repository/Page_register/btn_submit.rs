<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Przycisk do rejestracji</description>
   <name>btn_submit</name>
   <tag></tag>
   <elementGuidId>bfd9354b-7a2d-408b-be17-56bccaf2d4b6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[value = &quot;Register&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
