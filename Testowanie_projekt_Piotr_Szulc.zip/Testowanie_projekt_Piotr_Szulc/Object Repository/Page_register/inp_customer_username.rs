<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Identyfikator użytkownika</description>
   <name>inp_customer_username</name>
   <tag></tag>
   <elementGuidId>cd1d9dca-e14c-4030-8645-8a3720f24487</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer.username&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
