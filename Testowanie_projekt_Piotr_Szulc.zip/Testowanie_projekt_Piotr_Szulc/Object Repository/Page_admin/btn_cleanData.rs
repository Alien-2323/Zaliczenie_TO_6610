<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Wyczyszczenie bazy danych, aby możliwe było uruchomienie testu od nowa</description>
   <name>btn_cleanData</name>
   <tag></tag>
   <elementGuidId>c357f1e6-f956-4097-95ee-66e1ac706fec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button[value=&quot;CLEAN&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
