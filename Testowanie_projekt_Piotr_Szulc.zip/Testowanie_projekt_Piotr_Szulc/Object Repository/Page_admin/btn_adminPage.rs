<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Panel administratora</description>
   <name>btn_adminPage</name>
   <tag></tag>
   <elementGuidId>92da669c-5b83-4678-ae2b-c3b5e6f9b635</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#headerPanel > ul.leftmenu > li:nth-child(6) > a</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
