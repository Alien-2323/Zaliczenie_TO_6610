<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Opcja wylogowywania</description>
   <name>btn_logOut</name>
   <tag></tag>
   <elementGuidId>adf55a4f-6a64-4447-a865-d59da5a7c7df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#leftPanel > ul > li:nth-child(8) > a</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
