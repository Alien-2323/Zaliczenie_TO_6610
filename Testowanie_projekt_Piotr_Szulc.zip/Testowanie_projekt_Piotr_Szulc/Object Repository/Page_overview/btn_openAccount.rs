<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_openAccount</name>
   <tag></tag>
   <elementGuidId>f1f92f5f-f1c4-4b0f-ac4e-a8ae4412de25</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#leftPanel > ul > li:nth-child(1) > a</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
