import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

/*
 * Uruchomienie przegladarki i wejscie na strone
 */
WebUI.openBrowser('')

WebUI.navigateToUrl(rawUrl=GlobalVariable.url_login)

/*
 * Wprowadzenie nazwy uzytkownika
 */
WebUI.setText(findTestObject('Object Repository/Page_login/inp_login_username'), GlobalVariable.customer_username)

/*
 * Wprowadzenie nazwy uzytkownika
 */
WebUI.setEncryptedText(findTestObject('Object Repository/Page_login/inp_login_password'), GlobalVariable.customer_password)

/*
 * Uruchomienie opcji zaloguj
 */
WebUI.click(findTestObject('Object Repository/Page_login/btn_login'))

/*
 * Wybranie opcji zakladania konta
 */
WebUI.click(findTestObject('Object Repository/Page_overview/btn_openAccount'))

/*
 * Wybranie typu zakladanego konta
 */
WebUI.selectOptionByIndex(findTestObject('Object Repository/Page_openAccount/dropdown_type'), 1)

/*
 * Zaakceptowanie wyboru
 */
WebUI.click(findTestObject('Object Repository/Page_openAccount/btn_openAccount'))

/*
 * Przejscie do panelu administratora strony
 */
WebUI.click(findTestObject('Object Repository/Page_admin/btn_adminPage'))

/*
 * Wyczyszczenie bazy danych, aby bylo mozliwe ponowne przeprowadzenie testu
 */
WebUI.click(findTestObject('Object Repository/Page_admin/btn_cleanData'))

/*
 * Wylogowanie z konta
 */
WebUI.click(findTestObject('Object Repository/Page_admin/btn_logOut'))

/*
 * Zamykanie przegladarki
 */
WebUI.closeBrowser()



