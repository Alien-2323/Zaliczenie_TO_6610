import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

/*
 * Uruchomienie przegladarki z adresem aplikacji
 */
WebUI.openBrowser('')

WebUI.navigateToUrl(rawUrl=GlobalVariable.url_register)

/*
 * Wprowadzenie imienia uzytkownika
 */
WebUI.setText(findTestObject('Page_register/inp_customer_firstName'), GlobalVariable.customer_firstName)

/*
 * Wprowadzenie nazwiska uzytkownika
 */
WebUI.setText(findTestObject('Page_register/inp_customer_lastName'), GlobalVariable.customer_lastName)

/*
 * Wprowadzenie ulicy 
 */
WebUI.setText(findTestObject('Page_register/inp_customer_street'), customer_street)

/*
 * Wprowadzenie miasta
 */
WebUI.setText(findTestObject('Page_register/inp_customer_city'), customer_city)

/*
 * Wprowadzenie stanu
 */
WebUI.setText(findTestObject('Page_register/inp_customer_state'), customer_state)

/*
 * Wprowadzenie kodu pocztowego
 */
WebUI.setText(findTestObject('Page_register/inp_customer_zipCode'), customer_zipCode)

/*
 * Wprowadzenie numeru telefonu
 */
WebUI.setText(findTestObject('Page_register/inp_customer_phoneNumber'), GlobalVariable.customer_phoneNumber)

/*
 * Wprowadzenie numeru ssn
 */
WebUI.setText(findTestObject('Page_register/inp_customer_ssn'), customer_ssn)

/*
 * Wprowadzenie nazwy użytkownika
 */
WebUI.setText(findTestObject('Page_register/inp_customer_username'), GlobalVariable.customer_username)

/*
 * Wprowadzenie hasła użytkownika
 */
WebUI.setEncryptedText(findTestObject('Page_register/inp_customer_password'), GlobalVariable.customer_password)

/*
 * Powtórzenie hasła
 */
WebUI.setEncryptedText(findTestObject('Page_register/inp_repeatedPassword'), GlobalVariable.customer_password)

/*
 * Uruchomienie opcji rejestracji konta
 */
WebUI.click(findTestObject('Page_register/btn_submit'))

/*
 * Pobranie nazwy uzytkownika
 */
str_customer_name_elem = WebUI.getText(findTestObject('Page_register/str_customer_name'))

/*
 * Sprawdzenie wartosci oczekiwanej z nazwa uztkownika z aplikacji
 */
assert customer_name_exp == str_customer_name_elem

/*
 * Zamykanie przegladarki
 */
WebUI.closeBrowser()




