package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile paraban_test : Rejestracja konta w serwisie ParaBank</p>
     */
    public static Object url_register
     
    /**
     * <p>Profile paraban_test : Strona g&#322;&oacute;wna serwisu ParaBank</p>
     */
    public static Object url_login
     
    /**
     * <p>Profile paraban_test : Imi&#281; u&#380;ytkownika</p>
     */
    public static Object customer_firstName
     
    /**
     * <p>Profile paraban_test : Nazwisko u&#380;ytkownika</p>
     */
    public static Object customer_lastName
     
    /**
     * <p>Profile paraban_test : Adres u&#380;ytkownika - ulica</p>
     */
    public static Object customer_street
     
    /**
     * <p>Profile paraban_test : Adres u&#380;ytkownika - miasto</p>
     */
    public static Object customer_city
     
    /**
     * <p>Profile paraban_test : Adres u&#380;ytkownika - stan</p>
     */
    public static Object customer_state
     
    /**
     * <p>Profile paraban_test : Adres u&#380;ytkownika - kod pocztowy</p>
     */
    public static Object customer_zipCode
     
    /**
     * <p>Profile paraban_test : Numer telefonu u&#380;ytkownika</p>
     */
    public static Object customer_phoneNumber
     
    /**
     * <p>Profile paraban_test : Numer SSN (PESEL) u&#380;ytkownika</p>
     */
    public static Object customer_ssn
     
    /**
     * <p>Profile paraban_test : Identyfikator u&#380;ytkownika</p>
     */
    public static Object customer_username
     
    /**
     * <p>Profile paraban_test : Has&#322;o u&#380;ytkownika</p>
     */
    public static Object customer_password
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            url_register = selectedVariables['url_register']
            url_login = selectedVariables['url_login']
            customer_firstName = selectedVariables['customer_firstName']
            customer_lastName = selectedVariables['customer_lastName']
            customer_street = selectedVariables['customer_street']
            customer_city = selectedVariables['customer_city']
            customer_state = selectedVariables['customer_state']
            customer_zipCode = selectedVariables['customer_zipCode']
            customer_phoneNumber = selectedVariables['customer_phoneNumber']
            customer_ssn = selectedVariables['customer_ssn']
            customer_username = selectedVariables['customer_username']
            customer_password = selectedVariables['customer_password']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
